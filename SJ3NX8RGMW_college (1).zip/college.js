// LOGIN PAGE
const loginBtn = document.getElementById('loginBtn');
const emailInput = document.getElementById('email');
const errorMsg = document.getElementById('errorMsg');

const loginPage = document.getElementById('loginPage');
const branchPage = document.getElementById('branchPage');
const domainPage = document.getElementById('domainPage');

loginBtn.addEventListener('click', () => {
    const email = emailInput.value.trim();
    const regex = /^[0-9a-z]+@mlrit\.ac\.in$/;
    if (regex.test(email)) {
        loginPage.style.display = 'none';
        branchPage.style.display = 'block';
        spawnParticles(branchPage);
    } else {
        errorMsg.textContent = "Invalid college email!";
    }
});

// BRANCH SELECTION
document.querySelectorAll('.branch-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const branch = btn.getAttribute('data-branch');
        localStorage.setItem('branch', branch);
        branchPage.style.display = 'none';
        domainPage.style.display = 'block';
        spawnParticles(domainPage);
    });
});
document.getElementById('logoutBranch').addEventListener('click', () => {
    branchPage.style.display = 'none';
    loginPage.style.display = 'block';
});

// DOMAIN SEARCH
const experts = [{
        name: "Alice Reddy",
        id: "24R21A1001",
        contact: "9876543210",
        domain: "ai",
        image: "https://tse1.mm.bing.net/th/id/OIP.nGsBclf2X6LMrwlX4PSalAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3"
    },
    {
        name: "Bob Mehtha",
        id: "24R21A1002",
        contact: "9876543211",
        domain: "ml",
        image: "https://tse3.mm.bing.net/th/id/OIP.hrdwGTdr0flUsTbDKYdUqAHaII?rs=1&pid=ImgDetMain&o=7&rm=3"
    },
    {
        name: "Rahul Gupta",
        id: "24R21A1003",
        contact: "9876543212",
        domain: "web dev",
        image: "https://tse3.mm.bing.net/th/id/OIP.HhQeppmxc7QX96uPxK8kCQHaEv?rs=1&pid=ImgDetMain&o=7&rm=3"
    },
    {
        name: "karan verma",
        id: "24R21A1004",
        contact: "9876543213",
        domain: "data science",
        image: "https://m.media-amazon.com/images/M/MV5BYjQ3ZTRlZGItOTMwZi00ZGM0LTgzMjMtYjg2MWExYjJjMzVjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg"
    },
    {
        name: "Tanya Pillai",
        id: "24R21A1005",
        contact: "9876543214",
        domain: "cybersecurity",
        image: "https://tse1.mm.bing.net/th/id/OIP.fRX-3kEs_CUVMFvHcHYxRAHaJQ?rs=1&pid=ImgDetMain&o=7&rm=3"
    }
];

const searchBtn = document.getElementById('searchBtn');
const domainInput = document.getElementById('domainInput');
const resultsDiv = document.getElementById('results');
const domainAnimation = document.getElementById('domainAnimation');

searchBtn.addEventListener('click', () => {
    const domain = domainInput.value.trim().toLowerCase();
    resultsDiv.innerHTML = "";
    domainAnimation.innerHTML = "";

    switch (domain) {
        case "ai":
            domainAnimation.innerHTML = "🤖 Walking Robots";
            break;
        case "ml":
            domainAnimation.innerHTML = "🧠 Neural Network";
            break;
        case "web dev":
            domainAnimation.innerHTML = "💻 JS & CSS Logos";
            break;
        case "data science":
            domainAnimation.innerHTML = "📊 Charts & Graphs";
            break;
        case "cybersecurity":
            domainAnimation.innerHTML = "🛡️ Security Shield";
            break;
        default:
            domainAnimation.innerHTML = "🤩 Searching...";
    }

    const filtered = experts.filter(e => e.domain === domain);
    if (filtered.length === 0) {
        resultsDiv.innerHTML = "<p class='no-result'>No experts found 😢</p>";
    } else {
        filtered.forEach(e => {
            const card = document.createElement('div');
            card.classList.add('expert-card');
            card.innerHTML = `
                <div class="card-inner">
                    <div class="card-front">
                        <img src="${e.image}" alt="${e.name}">
                        <div>
                            <h3>${e.name}</h3>
                            <p>ID: ${e.id}</p>
                        </div>
                    </div>
                    <div class="card-back">
                        <p>Contact: ${e.contact}</p>
                        <p>Domain: ${e.domain.toUpperCase()}</p>
                    </div>
                </div>
            `;
            resultsDiv.appendChild(card);
        });
    }
});

// BACK & LOGOUT
document.getElementById('backBtn').addEventListener('click', () => {
    domainPage.style.display = 'none';
    branchPage.style.display = 'block';
});
document.getElementById('logoutDomain').addEventListener('click', () => {
    domainPage.style.display = 'none';
    loginPage.style.display = 'block';
});

// TECH PARTICLES
function spawnParticles(container) {
    for (let i = 0; i < 15; i++) {
        const p = document.createElement('div');
        p.classList.add('particle');
        p.style.left = Math.random() * 90 + '%';
        p.style.animationDuration = 5 + Math.random() * 5 + 's';
        const tech = ['< />', '⚡', '💻', '🧠', '⚙️', '🛡️', '📊'];
        p.textContent = tech[Math.floor(Math.random() * tech.length)];
        container.appendChild(p);
        setTimeout(() => {
            p.remove();
        }, 10000);
    }
}